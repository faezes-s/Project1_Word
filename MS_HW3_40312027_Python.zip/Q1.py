import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.interpolate import lagrange,CubicSpline
from scipy.integrate import trapezoid,simpson,quad

import sympy as sp
x_n=np.array([1,2,3,4,5,6])
y_n=np.array([1,3,5,8,5,2])
p_n=lagrange(x_n,y_n)
print(p_n)
print(p_n.coefficients)
p_n_c=CubicSpline(x_n,y_n)
x=sp.symbols("x")
polynom_n=[]
for i in range(len(x_n)-1):
    xi=x_n[i]
    coeff=p_n_c.c[:,i]
    a,b,c,d=coeff
    spl_c=(a*(x-xi)**3+b*(x-xi)**2+c*(x-xi)+d)
    polynom_n.append((spl_c,(x>=xi) & (x<=x_n[i+1])))

spline=sp.Piecewise(*polynom_n)
print(spline)


