import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.interpolate import lagrange,CubicSpline
from scipy.integrate import trapezoid,simpson,quad

import sympy as sp
from scipy.ndimage import label

data=pd.read_excel("پروژه 3 (1).xlsx")

print(data.head())
print(data.describe())





plt.plot(data[" Run time for different data size"],data["Alg.1"],label="Alg.1")
plt.plot(data[" Run time for different data size"],data["Alg.2"],label="Alg.2")
plt.plot(data[" Run time for different data size"],data["Alg.3"],label="Alg.3")

plt.legend()
plt.show()

plt.bar(data[" Run time for different data size"],data["Alg.1"],label="Alg.1")
plt.bar(data[" Run time for different data size"],data["Alg.2"],label="Alg.2")
plt.bar(data[" Run time for different data size"],data["Alg.3"],label="Alg.3")
plt.legend()
plt.show()

plt.boxplot([data["Alg.1"],data["Alg.2"],data["Alg.3"]])
plt.xticks([1,2,3],["Alg.1","Alg.2","Alg.3"])
plt.show()



data2=pd.DataFrame({

    " Run time for different data size":["700KB"],
    "Alg.1":[80],
    "Alg.2":[320],
    "Alg.3":[700]



})

data=pd.concat([data,data2],ignore_index=True)
print(data.head(7))
print(data.describe())

plt.plot(data[" Run time for different data size"],data["Alg.1"],label="Alg.1")
plt.plot(data[" Run time for different data size"],data["Alg.2"],label="Alg.2")
plt.plot(data[" Run time for different data size"],data["Alg.3"],label="Alg.3")

plt.legend()
plt.show()

plt.bar(data[" Run time for different data size"],data["Alg.1"],label="Alg.1")
plt.bar(data[" Run time for different data size"],data["Alg.2"],label="Alg.2")
plt.bar(data[" Run time for different data size"],data["Alg.3"],label="Alg.3")
plt.legend()
plt.show()

plt.boxplot([data["Alg.1"],data["Alg.2"],data["Alg.3"]])
plt.xticks([1,2,3],["Alg.1","Alg.2","Alg.3"])
plt.show()


print(data["Alg.2"])
mean_alg2_data=data["Alg.2"][0:6]
mean_alg2=np.mean(mean_alg2_data)
print(mean_alg2)