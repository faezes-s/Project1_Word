import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.interpolate import lagrange,CubicSpline
from scipy.integrate import trapezoid,simpson,quad
import sympy as sp
from sympy import integrate

x=np.linspace(0,1,101)
f=np.exp(x**2)
result=trapezoid(f,x)
print(result)

result_simp=simpson(f,x)
print(result_simp)
def func(x):
    return np.exp(x**2)

result_guass = quad(func,0,1)
print(result_guass)

